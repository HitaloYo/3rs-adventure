extends Area2D


func _on_body_entered(body):
	if body.is_in_group("player"):
		get_tree().change_scene_to_file("res://scenes/areas/area_reduzir/mundo_reduzir_fora_casa.tscn")
		 


func _on_body_exited(body: Node2D) -> void:
	pass # Replace with function body.
